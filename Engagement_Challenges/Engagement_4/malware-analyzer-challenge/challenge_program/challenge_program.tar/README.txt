
To start Malware Analyzer:
./run_challenge.sh

To supply example inputs to running Malware Analyzer:
./example_input.sh

If Malware Analyzer gives an error that the HTTP server could not be started, then another process is already listening on port 8001.
To find and kill that process:
netstat -tulpn | grep 8001
kill -9 <pid>
