#!/bin/sh

cat example_inputs/add_1.txt | curl -X POST http://localhost:8001 --data-urlencode @-
cat example_inputs/add_2.txt | curl -X POST http://localhost:8001 --data-urlencode @-
cat example_inputs/add_3.txt | curl -X POST http://localhost:8001 --data-urlencode @-
cat example_inputs/query.txt | curl -X POST http://localhost:8001 --data-urlencode @-
