#!/bin/sh

[ -n "$JAVA" ] || JAVA=java

CHALLENGE_JAR=malware_analyzer.jar
NANOHTTPD_JAR=nanohttpd-2.2.0.jar
if [ -d target ]; then
    CHALLENGE_JAR=target/"$CHALLENGE_JAR"
    NANOHTTPD_JAR=target/dependency/"$NANOHTTPD_JAR"
fi

MAIN_CLASS=com.ainfosec.MalwareAnalyzer.MalwareAnalyzer

set -x
"$JAVA" -Xmx4096m -Xint -cp "$CHALLENGE_JAR:$NANOHTTPD_JAR" "$MAIN_CLASS"
